from flask import Flask, render_template, request
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import joblib

app = Flask(__name__)

# Load model and scaler
model = joblib.load('diabetes_model.pkl')
scaler = joblib.load('scaler.pkl')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        data = {
            'Pregnancies': [int(request.form['Pregnancies'])],
            'Glucose': [int(request.form['Glucose'])],
            'BloodPressure': [int(request.form['BloodPressure'])],
            'SkinThickness': [int(request.form['SkinThickness'])],
            'Insulin': [int(request.form['Insulin'])],
            'BMI': [float(request.form['BMI'])],
            'DiabetesPedigreeFunction': [float(request.form['DiabetesPedigreeFunction'])],
            'Age': [int(request.form['Age'])]
        }
        df = pd.DataFrame(data)
        scaled_df = scaler.transform(df)
        prediction = model.predict(scaled_df)[0]
        result_class = 'result-positive' if prediction == 1 else 'result-negative'
        result_message = 'Positive: Diabetes detected' if prediction == 1 else 'Negative: No diabetes detected'
        return render_template('result.html', result_class=result_class, result_message=result_message)
    return render_template('predict.html')

if __name__ == '__main__':
    app.run(debug=True)


